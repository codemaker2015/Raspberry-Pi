package com.example.android.gcmapp;

/**
 * Created by my on 7/12/2016.
 */
public interface Connection {

    static final String APP_SERVER_URL = "http://192.168.0.117/sending-push-notifications.php?shareRegId=1";
    static final String GOOGLE_PROJECT_ID = "769537366212";

    static final String MESSAGE_KEY = "m";

}

