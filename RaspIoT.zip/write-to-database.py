#!C:\Users\Aradhana Kumar\AppData\Local\Enthought\Canopy\User\Scripts\python.exe

# Server side code to read data sent by pi through GET method.

import cgi, cgitb
import os
import time
import datetime
import glob
import MySQLdb
from time import strftime
import urllib

# Create instance of FieldStorage 
form = cgi.FieldStorage() 
# Get data from client
temp = form.getvalue('temp') 

print "Content-type:text/html\r\n\r\n"
print "<html>"
print "<head>"
print "<title>Data Storage</title>"
print "</head>"
print "</html>" 

temperature = float(temp)

# Alert user if recorded temperature is above a threshold (30 degrees in this case)
if temperature >= 30: 
  push = '1'
  message = 'Alert! Current temperature recorded is ' + str(temperature)
  url="http://localhost/sending-push-notifications.php?push="+push+"&message="+message 
  response = urllib.urlopen(url) #sends url request to another file responsible for sending GCM alerts
  data = response.read()
  print data
else:  
  print temp
  
#Code to write the recorded temperature in the MYSQL database 'templog' and table 'temp-at-interrupt'
db = MySQLdb.connect(host="localhost", user="root", passwd="raspberry", db="templog")
cur = db.cursor()

while True:
  dateWrite = time.strftime("%Y-%m-%d")
  timeWrite = time.strftime("%H:%M:%S")
  sql = ("""INSERT INTO `temp-at-interrupt` (`Date`, `Time`, `Temperature`) VALUES (%s,%s,%s);""", (dateWrite,timeWrite,temperature))
  try:
    cur.execute(*sql)
    db.commit()
    print "\nProcess finished"
  except:
    db.rollback()
    print "\nProcess Failed to Complete"

  cur.close()
  db.close()
  break
  

